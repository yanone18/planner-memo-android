package jp.yanone.plannermemo;
import android.app.*;import android.appwidget.*;import android.content.*;import android.widget.*;
public class ScheduleWidget extends AppWidgetProvider {
 public static void refresh(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);android.content.ComponentName cn=new android.content.ComponentName(c,ScheduleWidget.class);int[] ids=m.getAppWidgetIds(cn);for(int id:ids){m.notifyAppWidgetViewDataChanged(id,R.id.widget_list);update(c,m,id);}}
 static void update(Context c,AppWidgetManager m,int id){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);Intent i=new Intent(c,ScheduleService.class);i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);i.setData(android.net.Uri.parse(i.toUri(Intent.URI_INTENT_SCHEME)));v.setRemoteAdapter(R.id.widget_list,i);PendingIntent p=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);v.setPendingIntentTemplate(R.id.widget_list,p);v.setOnClickPendingIntent(R.id.widget_open,p);v.setTextViewText(R.id.widget_month,java.time.LocalDate.now().getYear()+"年"+java.time.LocalDate.now().getMonthValue()+"月");m.updateAppWidget(id,v);}
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);m.notifyAppWidgetViewDataChanged(ids,R.id.widget_list);}
}
