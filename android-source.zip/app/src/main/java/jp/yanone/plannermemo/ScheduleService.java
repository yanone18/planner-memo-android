package jp.yanone.plannermemo;
import android.content.*;import android.widget.*;import android.app.*;import org.json.*;import java.time.*;import java.time.format.*;import java.util.*;
public class ScheduleService extends RemoteViewsService {
 @Override public RemoteViewsFactory onGetViewFactory(Intent intent){return new Factory(getApplicationContext());}
 static class Factory implements RemoteViewsFactory {
  final Context ctx;JSONArray rows=new JSONArray();Factory(Context c){ctx=c;}
  @Override public void onCreate(){onDataSetChanged();}
  @Override public void onDataSetChanged(){rows=new JSONArray();try{JSONObject s=new JSONObject(ctx.getSharedPreferences("widget",MODE_PRIVATE).getString("state","{}"));JSONObject schedule=s.optJSONObject("schedule");if(schedule==null)schedule=new JSONObject();JSONArray repeats=s.optJSONArray("repeats");JSONObject exceptions=s.optJSONObject("repeatExceptions");LocalDate today=LocalDate.now();for(int n=0;n<365;n++){LocalDate d=today.plusDays(n);String key=d.toString(),value=schedule.optString(key,"");if(repeats!=null)for(int j=0;j<repeats.length();j++){JSONObject r=repeats.optJSONObject(j);if(r==null)continue;String start=r.optString("start","");try{LocalDate a=LocalDate.parse(start);if(d.isBefore(a))continue;int months=(d.getYear()-a.getYear())*12+d.getMonthValue()-a.getMonthValue();String f=r.optString("freq");int interval=f.equals("months1")?1:f.equals("months3")?3:f.equals("months6")?6:f.equals("yearly")?12:0;if(interval==0||months%interval!=0)continue;LocalDate occurrence=a.plusMonths(months);if(!occurrence.equals(d)||start.equals(key))continue;String text=r.optString("text","");String ex=r.optString("uid")+"|"+key;if(exceptions!=null&&exceptions.has(ex))text=exceptions.optString(ex,"");value+=text;}catch(Exception ignored){}}JSONObject row=new JSONObject();row.put("date",key);row.put("value",value);rows.put(row);}}catch(Exception ignored){}}
  @Override public void onDestroy(){}
  @Override public int getCount(){return rows.length();}
  @Override public RemoteViews getViewAt(int pos){if(pos<0||pos>=rows.length())return null;RemoteViews v=new RemoteViews(ctx.getPackageName(),R.layout.widget_row);try{JSONObject row=rows.getJSONObject(pos);LocalDate d=LocalDate.parse(row.getString("date"));String[] days={"月","火","水","木","金","土","日"};v.setTextViewText(R.id.day,d.getDayOfMonth()+"日("+days[d.getDayOfWeek().getValue()-1]+")");v.setTextColor(R.id.day,d.getDayOfWeek()==DayOfWeek.SUNDAY?0xffc03d4a:d.getDayOfWeek()==DayOfWeek.SATURDAY?0xff1769bd:0xff526175);v.setTextViewText(R.id.event,row.optString("value"));v.setOnClickFillInIntent(R.id.event,new Intent());}catch(Exception ignored){}return v;}
  @Override public RemoteViews getLoadingView(){return null;}
  @Override public int getViewTypeCount(){return 1;}
  @Override public long getItemId(int p){return p;}
  @Override public boolean hasStableIds(){return true;}
 }
}
