package jp.yanone.plannermemo;
import android.content.*;import android.widget.*;import android.app.*;import org.json.*;import java.time.*;import java.time.format.*;import java.util.*;
public class ScheduleService extends RemoteViewsService {
 @Override public RemoteViewsFactory onGetViewFactory(Intent intent){return new Factory(getApplicationContext());}
 static class Factory implements RemoteViewsFactory {
  final Context ctx;JSONArray rows=new JSONArray();Factory(Context c){ctx=c;}
  @Override public void onCreate(){onDataSetChanged();}
  @Override public void onDataSetChanged(){rows=new JSONArray();try{JSONObject s=new JSONObject(ctx.getSharedPreferences("widget",MODE_PRIVATE).getString("state","{}"));JSONObject schedule=s.optJSONObject("schedule");if(schedule==null)schedule=new JSONObject();JSONObject eventColors=s.optJSONObject("eventColors");LocalDate today=LocalDate.now();for(int n=0;n<365;n++){LocalDate d=today.plusDays(n);String key=d.toString(),value=schedule.optString(key,"");JSONObject row=new JSONObject();row.put("date",key);row.put("value",value);
if(eventColors!=null){JSONObject style=eventColors.optJSONObject(key);if(style!=null)row.put("style",style);}
rows.put(row);}}catch(Exception ignored){}}
  @Override public void onDestroy(){}
  @Override public int getCount(){return rows.length();}
  @Override public RemoteViews getViewAt(int pos){if(pos<0||pos>=rows.length())return null;RemoteViews v=new RemoteViews(ctx.getPackageName(),R.layout.widget_row);try{JSONObject row=rows.getJSONObject(pos);LocalDate d=LocalDate.parse(row.getString("date"));String[] days={"月","火","水","木","金","土","日"};v.setTextViewText(R.id.day,d.getDayOfMonth()+"日("+days[d.getDayOfWeek().getValue()-1]+")");v.setTextColor(R.id.day,d.getDayOfWeek()==DayOfWeek.SUNDAY?0xffc03d4a:d.getDayOfWeek()==DayOfWeek.SATURDAY?0xff1769bd:0xff526175);v.setTextViewText(R.id.event,row.optString("value"));
JSONObject style=row.optJSONObject("style");
if(style!=null){
 String bg=style.optString("bg","");
 int drawable=0;
 switch(bg){
 case "#B63838":drawable=R.drawable.widget_event_red;break;
 case "#C66A27":drawable=R.drawable.widget_event_orange;break;
 case "#D9AE32":drawable=R.drawable.widget_event_yellow;break;
 case "#367B51":drawable=R.drawable.widget_event_green;break;
 case "#3266A0":drawable=R.drawable.widget_event_blue;break;
 case "#283F68":drawable=R.drawable.widget_event_navy;break;
 case "#744A8E":drawable=R.drawable.widget_event_purple;break;
 case "#777777":drawable=R.drawable.widget_event_gray;break;
 }
 if(drawable!=0){
  v.setInt(R.id.event,"setBackgroundResource",drawable);
  v.setTextColor(R.id.event,"#000000".equals(style.optString("fg"))?0xff000000:0xffffffff);
  v.setTextViewTextSize(R.id.event,android.util.TypedValue.COMPLEX_UNIT_SP,12.5f);
 }
}v.setOnClickFillInIntent(R.id.event,new Intent());}catch(Exception ignored){}return v;}
  @Override public RemoteViews getLoadingView(){return null;}
  @Override public int getViewTypeCount(){return 1;}
  @Override public long getItemId(int p){return p;}
  @Override public boolean hasStableIds(){return true;}
 }
}
